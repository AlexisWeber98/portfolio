import type { Project } from "@/lib/types"

export const projects: Project[] = [
  {
    id: "postulate",
    title: "Postulate",
    description: {
      en: "Job application platform connecting candidates with opportunities. Features include profile management, application tracking, and real-time notifications.",
      es: "Plataforma de postulación laboral que conecta candidatos con oportunidades. Incluye gestión de perfiles, seguimiento de aplicaciones y notificaciones en tiempo real.",
    },
    image: "/job-application-platform-interface.jpg",
    tags: ["Next.js", "TypeScript", "PostgreSQL", "Tailwind"],
    link: "https://postulateok.com",
    featured: true,
  },
  {
    id: "craftbeer",
    title: "Craft Beer Shop",
    description: {
      en: "E-commerce platform for craft beer enthusiasts. Features product catalog, shopping cart, payment integration, and order management.",
      es: "Plataforma de comercio electrónico para entusiastas de la cerveza artesanal. Incluye catálogo de productos, carrito de compras, integración de pagos y gestión de pedidos.",
    },
    image: "/craft-beer-ecommerce-shop.jpg",
    tags: ["React", "Node.js", "Stripe", "MongoDB"],
    link: "https://craftbeershop.vercel.app",
    featured: true,
  },
  // {
  //   id: "unique-project-id",
  //   title: "Project Name",
  //   description: {
  //     en: "English description of the project",
  //     es: "Descripción en español del proyecto",
  //   },
  //   image: "/project-description.jpg",
  //   tags: ["Tech1", "Tech2", "Tech3"],
  //   link: "https://project-url.com", // Optional
  //   github: "https://github.com/username/repo", // Optional
  //   featured: false, // Set to true for featured projects
  // },
]
